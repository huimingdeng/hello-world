<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "comment".
 *
 * @property string $id
 * @property string $content
 * @property string $status
 * @property int $create_time
 * @property int $userid
 * @property string $email
 * @property string $url
 * @property string $postid
 *
 * @property Posts $post
 * @property Commentstatus $status0
 * @property User $user
 */
class Comment extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'comment';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['content'], 'required'],
            [['content'], 'string'],
            [['status', 'create_time', 'userid', 'postid'], 'integer'],
            [['email', 'url'], 'string', 'max' => 128],
            [['postid'], 'exist', 'skipOnError' => true, 'targetClass' => Posts::className(), 'targetAttribute' => ['postid' => 'id']],
            [['status'], 'exist', 'skipOnError' => true, 'targetClass' => Commentstatus::className(), 'targetAttribute' => ['status' => 'id']],
            [['userid'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['userid' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'content' => '评论',
            'status' => '状态',
            'create_time' => '发布时间',
            'userid' => '用户',
            'email' => '邮件',
            'url' => '链接',
            'postid' => '文章',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPost()
    {
        return $this->hasOne(Posts::className(), ['id' => 'postid']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStatus0()
    {
        return $this->hasOne(Commentstatus::className(), ['id' => 'status']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'userid']);
    }
    /**
     * 截取字符串
     * @return [type] [description]
     */
    public function getBeginning(){
        $tmpStr = strip_tags($this->content);//清除HTML标签
        $tmpLen = mb_strlen($tmpStr);
        return mb_substr($tmpStr, 0, 20, 'utf-8').($tmpLen>20)?'...':'';
    }
    /**
     * 审核
     * @return [type] [description]
     */
    public function approve(){
        $this->status = 2; //修改为2：已审核
        return ($this->save()?true:false);
    }
    /**
     * 待审核条数
     * @return [type] [description]
     */
    public static function getPengdingCommentCount()
    {
        return Comment::find()->where(['status'=>1])->count();
    }

    /**
     * 框架 save 保存数据前最后可控的一步，用于设置创建时间，修改时间等
     * @param  [type] $insert [description]
     * @return [type]         [description]
     */
    public function beforeSave($insert){
        // 调用父类方法，保证原先代码可执行
        if(parent::beforeSave($insert)){
            if($insert){
                $this->create_time = time();
                $this->update_time = time();
            }else{
                $this->update_time = time();
            }
            return true;
        }else{
            return false;
        }
    }
}
