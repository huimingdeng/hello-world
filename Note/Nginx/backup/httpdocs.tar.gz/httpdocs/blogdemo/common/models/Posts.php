<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "posts".
 *
 * @property string $id
 * @property string $title
 * @property string $content
 * @property string $tags
 * @property string $categoryid
 * @property string $status
 * @property int $create_time
 * @property int $update_time
 * @property string $author_id
 *
 * @property Comment[] $comments
 * @property Adminuser $author
 * @property Category $category
 * @property Poststatus $status0
 */
class Posts extends \yii\db\ActiveRecord
{
    private $_oldTags;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'posts';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['title', 'content', 'author_id'], 'required'],
            [['content', 'tags'], 'string'],
            [['categoryid', 'status', 'create_time', 'update_time', 'author_id'], 'integer'],
            [['title'], 'string', 'max' => 128],
            [['author_id'], 'exist', 'skipOnError' => true, 'targetClass' => Adminuser::className(), 'targetAttribute' => ['author_id' => 'id']],
            [['categoryid'], 'exist', 'skipOnError' => true, 'targetClass' => Category::className(), 'targetAttribute' => ['categoryid' => 'id']],
            [['status'], 'exist', 'skipOnError' => true, 'targetClass' => Poststatus::className(), 'targetAttribute' => ['status' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => '标题',
            'content' => '内容',
            'tags' => '标签',
            'categoryid' => '分类',
            'status' => '状态',
            'create_time' => '创建时间',
            'update_time' => '修改时间',
            'author_id' => '作者',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getComments()
    {
        return $this->hasMany(Comment::className(), ['postid' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAuthor()
    {
        return $this->hasOne(Adminuser::className(), ['id' => 'author_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCategory()
    {
        return $this->hasOne(Category::className(), ['id' => 'categoryid']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStatus0()
    {
        return $this->hasOne(Poststatus::className(), ['id' => 'status']);
    }

    /**
     * 框架 save 保存数据前最后可控的一步，用于设置创建时间，修改时间等
     * @param  [type] $insert [description]
     * @return [type]         [description]
     */
    public function beforeSave($insert){
        // 调用父类方法，保证原先代码可执行
        if(parent::beforeSave($insert)){
            if($insert){
                $this->create_time = time();
                $this->update_time = time();
            }else{
                $this->update_time = time();
            }
            return true;
        }else{
            return false;
        }
    }
    /**
     * 修改前，保存旧标签
     * @return [type] [description]
     */
    public function afterFind(){
        parent::afterFind();//重新方法前，都要调用一下父类方法
        $this->_oldTags = $this->tags;
    }

    /**
     * 保存后，更新标签
     * @param  int $insert            是否插入操作
     * @param   $changedAttributes [description]
     * @return [type]                    [description]
     */
    public function afterSave($insert, $changedAttributes){
        parent::afterSave($insert,$changedAttributes);
        Tag::updateFrequency($this->_oldTags,$this->tags);
    }
    /**
     * 删除后，清空标签
     * @return [type] [description]
     */
    public function afterDelete(){
        parent::afterDelete();
        Tag::updateFrequency($this->tags,'');
    }
}
