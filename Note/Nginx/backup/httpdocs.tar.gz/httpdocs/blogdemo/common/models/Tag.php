<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tag".
 *
 * @property string $id
 * @property string $name 标签名
 * @property int $frequency
 */
class Tag extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tag';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name'], 'required'],
            [['frequency'], 'integer'],
            [['name'], 'string', 'max' => 128],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'frequency' => 'Frequency',
        ];
    }

    /**
     * 将tag转换成数组
     * @param  string $tags 文章标签
     * @return array       标签数组
     */
    public static function string2array($tags){
        return preg_split('/\s*,\s*/',trim($tags),-1,PREG_SPLIT_NO_EMPTY);
    }

    /**
     * 将tag数组转换成字符串
     * @param  array $tags 标签数组
     * @return string       标签字符串
     */
    public static function array2string($tags){
        return implode(',', $tags);
    }

    /**
     * 添加标签
     * @param array $tags 标签数组
     */
    public static function addTags($tags){
        if(empty($tags)) return;//判断是否为空，则表示没有修改

        foreach ($tags as $name) {//循环处理，查询是否已经存在标签
            $nTag = Tag::find()->where(['name'=>$name])->one();
            $nTagCount = Tag::find()->where(['name'=>$name])->count();
            if(!$nTagCount){//标签不存在则添加标签
                $tag = new Tag();
                $tag->name=$name;
                $tag->frequency=1;
                $tag->save();
            }else{//存在，则标签频率＋1
                $nTag->frequency+=1;
                $nTag->save();
            }
        }
    }

    /**
     * 删除标签
     * @param  array $tags 标签数组
     */
    public static function removeTags($tags){
        if(empty($tags)) return;//判断是否为空，则表示没有修改

        foreach ($tags as $name) {//循环处理，查询是否已经存在标签
            $nTag = Tag::find()->where(['name'=>$name])->one();
            $nTagCount = Tag::find()->where(['name'=>$name])->count();
            if($nTagCount){//标签存在
                if($nTagCount && $nTagCount<=1){
                    $nTag->delete();
                }else{
                    $nTag->frequency-=1;
                    $nTag->save();
                }
            }
        }
    }

    /**
     * 更新标签
     * @param  string $oldTags 旧标签
     * @param  string $newTags 新标签
     */
    public static function updateFrequency($oldTags,$newTags){
        if(!empty($oldTags) || !empty($newTags)){
            $oldTagsArray = self::string2array($oldTags);
            $newTagsArray = self::string2array($newTags);

            self::addTags(array_values(array_diff($newTagsArray, $oldTagsArray)));
            self::removeTags(array_values(array_diff($oldTagsArray,$newTagsArray)));
        }
    }

}
