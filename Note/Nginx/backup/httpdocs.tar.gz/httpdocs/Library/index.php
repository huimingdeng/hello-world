<?php
echo "test".dirname(__FILE__);
