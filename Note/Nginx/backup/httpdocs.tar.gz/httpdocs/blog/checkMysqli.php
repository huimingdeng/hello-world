<?php
var_dump(function_exists('mysqli_connect'));
print_r(get_loaded_extensions());

