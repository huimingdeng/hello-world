<?php
namespace config

class DB{
	private static $_instance = NULL;
	private $host;
	private $user;
	private $pass;
	private $db;
	private $table;
	public $sql;
	private $charset = "utf8";
	private $con;
	private $errorMsg;
	private $res;
	

	public function __construct($host,$user,$pass,$db){
		//test
		
	}
	public static function get_instance($host,$user,$pass,$db){
		if(NULL==self::$_instance){
			self::$_instance = new self($host,$user,$pass,$db);
		}
		return self::$_instance;
	}
	/**
	* 链接数据库
	*/
	public function connectdb($host,$user,$pass,$db){
		$this->con = new mysqli();
		$this->con -> connect($host,$user,$pass,$db);
		if($this->con->errno){
			$this->errorMsg = "Connect faile: ".$this->con->error." \n";
		}
		$this->con->set_charset($this->charset);
	}
	/**
	* 查询数据表
	* @param string $table 数据表名
	* @param string $fields 字段名 eg field1,field2
	* @param string $where 查询条件
	* @return array $res 查询结果，二位数组
	*/
	public function select($table,$fields="*",$where=""){
		$this->sql = "SELECT $fields FROM $table ";
		(!empty($where))?$this->sql.=" ".$where:$this->sql;
		$this->res = $this->con->query($this->sql);
		$temp = array();
		while($row=mysqli_fetch_assoc($this->res)){
			$temp[]=$row;
		}
		$this->res = $temp;
		return $this->res;
	}
	/**
	* 获取 SQL 语句，验证是否为所需的 SQL 语句
	*/
	public function getSql(){
		return $this->sql;
	}
	
	public function closeDb(){
		if($this->con->close()){
			return "Closed $this->db success.\n";
		}else{
			$this->closeDb();
		}
	}
}
