<?php
try{
	$dsn = 'mysql:host=localhost;dbname=mysqlilearn';
	$user = 'root';
	$pass = 'DHM529828';
	$pdo = new PDO($dsn,$user,$pass);
	var_dump($pdo);
}catch(PDOException $e){
	echo $e->getMessage();
}
