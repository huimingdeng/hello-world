<?php
/*try{
	$dsn = 'uri:file:////home/weixin/httpdocs/blog/config/config.conf';
	$user = 'root';
	$pass = 'DHM529828';
	$pdo = new PDO($dsn,$user,$pass);
	var_dump($pdo);
}catch(PDOException $e){
	echo $e->getMessage();
}*/
