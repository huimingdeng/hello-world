<?php
$mysqli = new mysqli();
$mysqli -> connect("localhost","root","DHM529828","mysqlilearn");
if($mysqli->connect_errno){
	printf("Connect failed: %s\n",$mysqli->connect_error);
	exit;
}

$sql_insert = "insert into user(username,passwd,nickname,email,phone) values('huimingdeng','".md5("DHM529828blog")."','ming','1458575181@qq.com','13570313864')";
if($mysqli->query($sql_insert)==true){
	printf("Ok!\n");
}else{
	printf("Insert failed: %s\n",$mysqli->error);
}

$mysqli -> close();
