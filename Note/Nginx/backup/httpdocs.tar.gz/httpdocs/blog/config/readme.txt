
pdouri.php 使用 uri 形式失败
	目前显示的错误为：php_network_getaddresses: getaddrinfo failed: Temporary failure in name resolutin
	
	查找为 DNS 解析错误 使用 file_get_contents 方法错误？
	
	问题未解决--
			2018.03.21


