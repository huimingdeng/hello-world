<?php
/**
 * gd2 库运用 -- 未测试
 * Author: Ming
 * DATE: 2018/03/24
 * VERSION: 1.0
 */
class CompressImg 
{
	private $image;//内存中图片----生成的图片
	private $info;//图片信息

	/**
	 * 打开图片
	 * @param string $filename 
	 */
	public function __construct($filename)
	{
		$info=getimagesize($filename);
		$this->info=array(
			'width' => $info[0],
			'height' => $info[1],
			'type' => image_type_to_extension($info[2],false),//eg. jpeg/png/gif
			'mime' => $info['mime']
		);
		//创建可变函数名，用于生成图片用 imagecreatefromjpeg/imagecreatefromgif/imagecreatefrompng
		// $imgfunc = "imagecreatefrom".$this->info['type'];
		// $this->image = $imgfunc($filename);
		$this->image = self::getMakeImgFunc($this->info['type'],$filename);
	}
	/**
	 * 操作图片，进行压缩
	 * @param  integer $width  压缩图片宽度
	 * @param  integer $height 压缩图片高度
	 * @return 
	 */
	public function thumb($width,$height){
		$image_thumb = imagecreatetruecolor($width, $height);
		imagecopyresampled($image_thumb, $this->image, 0, 0, 0, 0, $width, $height, $this->info['width'], $this->info['height']);
		imagedestroy($this->image);//销毁内存中的图片
		$this->image = $image_thumb;//压缩后的图片
	}
	/**
	 * 操作图片，添加文字水印
	 * @param  string $content  水印文本
	 * @param  string $font_url 字体文件路径
	 * @param  integer $size     图片大小
	 * @param  array $colors rgba 三原色+透明度 array(red=>255,green=>255,blue=>255,alpha=>20)
	 * @param  array $local    字体位置 array(x=>'horizontal axis',y=>'vertical axis') eg. array(x=>20,y=>50)
	 * @param  integer $angle    水印偏移角度 eg. 30 -- 偏移旋转30度
	 * @return    
	 */
	public function fontMark($content, $font_url, $size, $colors, $local, $angle){
		$font_color = imagecolorallocatealpha($this->image, $colors['red'], $colors['green'], $colors['blue'], $colors['alpha']);//字体颜色
		imagettftext($this->image, $size, $angle, $local['x'], $local['y'], $font_color, $font_url, $content);
	}
	/**
	 * 操作图片，添加图片水印
	 * @param  string $source 
	 * @param  array  $local  水印图位置
	 * @param  integer $alpha  透明度
	 * @return 
	 */
	public function imageMark($source, $local, $alpha){
		$markinfo = getimagesize($source);
		$type = image_type_to_extension($markinfo[2],false);
		$water = self::getMakeImgFunc($type,$source);//水印图
		// 合并图片，添加水印
		imagecopymerge($this->image, $water, $local['x'], $local['y'], 0, 0, $markinfo[0], $markinfo[1], $alpha);
		imagedestroy($water);//销毁水印图
	}
	/**
	 * 浏览器中输出图片
	 * @return 
	 */
	public function showImg(){
		header("Content-type:".$this->info['mime']);
		$imgfunc = "image{$this->info['type']}";
		$imgfunc($this->image);
	}
	/**
	 * 保存图片
	 * @param string $newname 新图片名字，不含扩展名
	 * @return 
	 */
	public function saveImg($newname){
		$imgfunc = "image{$this->info['type']}";
		$imgfunc($this->image,$newname.'.'.$this->info['type']);
	}
	/**
	 * 根据类型，创建图片
	 * @param  string $imageType 源图片类型 jpeg/gif/png
	 * @param string $filesrc 需要创建（复制）的图片路径
	 * @return 返回生产的图片
	 */
	private static function getMakeImgFunc($imageType,$filesrc){
		return "imagecreatefrom".$imageType($argument);
	}
	/**
	 * 销毁图片,析构函数
	 * @return 
	 */
	public function __destruct(){
		imagedestroy($this->image);
	}
}
