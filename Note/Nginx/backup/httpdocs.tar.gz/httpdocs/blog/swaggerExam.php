<?php
require('vendor/autoload.php');
$swagger=\Swagger\scan('/home/weixin/httpdocs/blog');//??
// header('Content-Type: application/json');
echo $swagger;
