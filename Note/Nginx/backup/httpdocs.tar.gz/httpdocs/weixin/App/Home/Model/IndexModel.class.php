<?php
namespace Home\Model;
/**
* 
*/
class IndexModel 
{
	
	function __construct()
	{
		# code...
	}
	/**
	 * 返回图文消息
	 * @param  Object 		$postObj 微信xml解析后对象
	 * @param  Array 	 	$article     图文消息的数组，包含 title,descript,picUrl,url
	 * @return String       		 返回XML结构的结果
	 */
	public function responseNews($postObj,$article){
		$toUser = $postObj->FromUserName;
		$fromUser = $postObj->ToUserName;
		$template = "<xml>
				<ToUserName><![CDATA[%s]]></ToUserName>
				<FromUserName><![CDATA[%s]]></FromUserName>
				<CreateTime>%s</CreateTime>
				<MsgType><![CDATA[%s]]></MsgType>
				<ArticleCount>".count($article)."</ArticleCount>
				<Articles>";
		foreach ($article as $k => $v) {
			$template.=	"<item>
					<Title><![CDATA[".$v['title']."]]></Title> 
					<Description><![CDATA[".$v['description']."]]></Description>
					<PicUrl><![CDATA[".$v['picUrl']."]]></PicUrl>
					<Url><![CDATA[".$v['url']."]]></Url>
				</item>";
		}
		$template .= "</Articles>
			</xml>";
		echo sprintf($template,$toUser,$fromUser,time(),'news');
	}
	/**
	 * 返回文本消息
	 * @param  Object 		$postObj 微信xml解析后对象
	 * @param  String 		$content 需要返回的文本消息
	 * @return String          组装后返回的文本消息
	 */
	public function responseText($postObj,$content){
		$toUser = $postObj->FromUserName;
		$fromUser = $postObj->ToUserName;
		$time = time();
		$Msgtype = 'text';
		$template = "<xml> 
					<ToUserName><![CDATA[%s]]></ToUserName> 
					<FromUserName><![CDATA[%s]]></FromUserName> 
					<CreateTime>%s</CreateTime> 
					<MsgType><![CDATA[%s]]></MsgType> 
					<Content><![CDATA[%s]]></Content> 
					</xml>";
		echo sprintf($template,$toUser,$fromUser,$time,$Msgtype,$content);
	}

	/**
	 * 天气查询 —— 未实现
	 * @param  [type] $postObj [description]
	 * @param  [type] $city    [description]
	 * @return [type]          [description]
	 */
	public function responseWeather($postObj,$city){
		$apikey="043f7e69c17611d5d32afb7c6ccf79f1";//百度
		
		$ch = curl_init();
	    $url = 'https://www.sojson.com/open/api/weather/json.shtml?city='.$city;
	    
	    curl_setopt($ch , CURLOPT_URL , $url);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	    // 执行HTTP请求
	    $res = curl_exec($ch);
	    $res = json_decode($res);
	    curl_close($ch);
	    $content = $city."---".$res;
		$this->responseText($postObj,$content);
    }
}
