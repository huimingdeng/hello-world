<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        // 获得参数 signature nonce token timestamp echostr
        $timestamp = $_GET['timestamp'];
        $nonce = $_GET['nonce'];
        $token = 'DHMing';
        $signature = $_GET['signature'];
        $echostr = $_GET['echostr'];

        $array = array($nonce,$timestamp,$token);
        sort($array);
        $tmpstr = implode('',$array);
        $tmpstr = sha1($tmpstr);
        if($tmpstr == $signature && $echostr){
                echo $echostr;
                exit;
        }else{
        	$this->responseMsg();
        }
        
    }

    public function responseMsg(){
    	//1.获取微信post推送的xml数据
		//$postArr = $GLOBALS['HTTP_RAW_POST_DATA'];
		$postArr = file_get_contents("php://input");
		//2.设置处理消息
		/**
		 * <xml>
		 * 		<ToUserName><![CDATA[toUser]]></ToUserName>
		 *   	<FromUserName><![CDATA[FromUser]]></FromUserName>
		 *    	<CreateTime>123456789</CreateTime>
		 *     	<MsgType><![CDATA[event]]></MsgType>
		 *      <Event><![CDATA[subscribe] ]></Event>
		 * </xml>
		*/

		$postObj = simplexml_load_string($postArr);
		// $postObj -> ToUserName = '';
		// $postObj -> FromUserName = '';
		// $postObj -> CreateTime = '';
		// $postObj -> MsgType = '';
		// $postObj -> Event = '';
		
		//判断该数据包是否是订阅的事件推送
		if( strtolower($postObj->MsgType) == 'event'){
			if(strtolower($postObj->Event)=='subscribe'){
				//回复消息
				$toUser = $postObj -> FromUserName;
				$fromUser = $postObj -> ToUserName;
				$content = '欢迎关注本公众号'.$toUser.'-'.$fromUser;
				$responseText = new \Home\Model\IndexModel();
				$responseText->responseText($postObj,$content);
				
			}elseif(strtoupper($postObj->Event)=='LOCATION'){
				/**
				 * 用户定位提交请求--以后返回天气信息
				 * <xml>
				 * 		<ToUserName>< ![CDATA[toUser] ]></ToUserName>
				 *   	<FromUserName>< ![CDATA[fromUser] ]></FromUserName>
				 *    	<CreateTime>123456789</CreateTime>
				 *     	<MsgType>< ![CDATA[event] ]></MsgType>
				 *      <Event>< ![CDATA[LOCATION] ]></Event>
				 *      <Latitude>23.137466</Latitude>
				 *      <Longitude>113.352425</Longitude>
				 *      <Precision>119.385040</Precision>
				 * </xml>
				*/
				$content = '您好，'.$postObj->ToUserName.",位置于(".$postObj->Latitude.",".$postObj->Longitude.")";
				$responseText->responseText($postObj,$content);
			}
		}

		if(strtolower($postObj->MsgType == 'text') && trim($postObj->Content) == 'tuwen2'){
			
			$article = array(
				array(
					'title'=>'imooc',
					'description'=>"imooc is very cool",
					'picUrl'=>'http://123.207.74.118/weixin/Public/aimind.png',
					'url'=>'https://www.imooc.com',
				),
				array(
					'title'=>'model page',
					'description'=>'test',
					'picUrl'=>'http://123.207.74.118/weixin/Public/wukong.jpg',
					'url'=>'http://mp.weixin.qq.com/mp/homepage?__biz=MzIwMzA4NDU0MA==&hid=1&sn=9f7fd202648ea210ce4c79d3bdb118c5#wechat_redirect'
					)
			);
			$responseNews = new \Home\Model\IndexModel();
			$responseNews->responseNews($postObj,$article);

		}elseif(strtolower($postObj->MsgType == 'text') && preg_match( '/^weather-/',trim($postObj->Content) ) ){
			$city=preg_replace('/^weather-/','',trim($postObj->Content));
			$responseWeather = new \Home\Model\IndexModel();
			$responseWeather->responseWeather($postObj,$city);
		}
		else{
			
			switch ( strtolower( trim($postObj->Content) ) ){
				case 'test':
					$content = 'test '.$postObj->FromUserName;;
					break;
				case 'run':
					$content = 'run '.$postObj->ToUserName;
					break;
				case 'msgid':
					$content = $postObj->MsgId;
					break;
				case 'help':
					$content = "输入 'weather-北京' 查询天气";
					break;
				default:
					$content = "欢迎使用本公众号";
					break;
			}
			//回复消息
			$responseText = new \Home\Model\IndexModel();
			$responseText->responseText($postObj,$content);
		}
		

    }

    
}
