<?php
return array(
	//'配置项'=>'配置值'
//	'DEFAULT_MODULE' => 'Index',
//	'URL_MODEL' => 2,
//	'SESSION_AUTO_START' => true,
);
