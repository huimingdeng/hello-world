<?php
define('APP_NAME','weixin');
define('APP_PATH','./App/');
define('APP_DEBUG',True);
// 引入ThinkPHP入口文件
require './ThinkPHP/ThinkPHP.php';
