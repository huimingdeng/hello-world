<?php
//echo (isset($_GET))?$_GET['p']:"";
echo "hello";
