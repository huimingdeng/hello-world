#!/usr/bin/env python
#-*- coding: utf-8 -*-
h="hello";
print(h+" world");

print("deepth learn");
