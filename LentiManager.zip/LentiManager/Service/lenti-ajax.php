<?php 
require_once(dirname(dirname(dirname(dirname(dirname(__FILE__)))))."/wp-config.php");
global $wpdb;
global $user_login;
get_currentuserinfo();

if (!function_exists("GetSQLValueString")) {
	function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
	{
		$theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
		// $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);
		$theValue = mysql_escape_string($theValue);//' /wp-content/plugins/promotion_tag/functions.php' 函数也修改

		switch ($theType) {
			case "text":
			$theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
			break;    
			case "long":
			case "int":
			$theValue = ($theValue != "") ? intval($theValue) : "NULL";
			break;
			case "double":
			$theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
			break;
			case "date":
			$theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
			break;
			case "defined":
			$theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
			break;
		}
		return $theValue;
	}
}

if($user_login){
	$action = $_REQUEST['action'];

	if ($action=="listAll") {
		$sql = "SELECT * FROM _cs_lenti_collection";
		$results = $wpdb->get_results($sql);
		$response = array(
			// 'sql'=>$sql,
			'data' => $results
			);
		echo json_encode($response);
	}
	//处理查询指定产品的操作，返回单条记录
	if ($action=="listOne" || $action=="queryRep") {
		$catalog = trim( stripslashes( $_REQUEST['catalog'] ) );
		if( preg_match( "/^[A-Za-z0-9_\-]+$/", $catalog ) ){//验证通过时查询
			$sql = sprintf( "SELECT * FROM _cs_lenti_collection WHERE BINARY catalog = %s", GetSQLValueString( $catalog, "text" ) );
			switch ($action) {
				case 'listOne':
				$query = $wpdb->get_row($sql);
				break;
				case 'queryRep':
				$query = $wpdb->query($sql);
				break;
			}
			echo json_encode($query);
		}
	}
}