Version Description
0.1.0 新加版本，只有lenti-list.php/和入口文件
0.1.1 引入 lib/ 目录，lenti-list.php 引入相关操作按钮
0.1.2 引入 layer 插件，优化页面
0.2.0 修改入口文件 lentiManager.php 添加了插件激活和禁用操作；激活插件创建_cs_lenti_collection_delete_back备份表和创建触发器_cs_lenti_collection_trigger，插件禁用则删除备份表和删除触发器
0.2.1 修改入口文件 lentiManager.php 删除触发器的创建
0.2.2 新增 添加/修改模态框，用于对lenti数据的修改。
0.2.3 lenti-ajax.php 实现添加单条记录
0.2.4 lenti-ajax.php 实现单条记录修改
0.2.5 添加删除模态框 lenti-list.php 
0.2.6 lenti-ajax.php 实现删除数据，备份数据到 _cs_lenti_collection_delete_back 
0.3.0 新增回收站页 lenti-recycle-bin.php, lentiManager.php 入口页新增引入页面程序
0.3.1 新增批量回复数据 lenti-ajax.php 