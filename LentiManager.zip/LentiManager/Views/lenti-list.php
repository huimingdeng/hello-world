<?php ?>
<link rel="stylesheet" type="text/css" href="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/css/dataTables.bootstrap.css">
<link rel="stylesheet" type="text/css" href="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/lib/Buttons-1.1.2/css/buttons.bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/lib/Responsive-2.1.0/css/responsive.bootstrap.min.css">

<script type="text/javascript" language="javascript" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/js/jquery-1.12.3.min.js">
</script>
<script type="text/javascript" language="javascript" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/js/jquery.dataTables.min.js">
</script>
<script type="text/javascript" language="javascript" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/js/dataTables.bootstrap.min.js">
</script>
<!-- Layer -->
<script type="text/javascript" charset="utf8" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/lib/layer-v2.3/layer.js">
</script>
<script type="text/javascript" language="javascript" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/js/bootstrap.min.js">
</script>
<!-- Buttons dt -->
<script type="text/javascript" charset="utf8" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/lib/Buttons-1.1.2/js/dataTables.buttons.min.js">
</script>
<!-- Buttons bt -->
<script type="text/javascript" charset="utf8" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/lib/Buttons-1.1.2/js/buttons.bootstrap.min.js">
</script>
<!-- jszip -->
<script type="text/javascript" charset="utf8" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/lib/Buttons-1.1.2/js/jszip.min.js">
</script>
<!-- pdfmake -->
<script type="text/javascript" charset="utf8" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/lib/Buttons-1.1.2/js/pdfmake.min.js">
</script>
<!-- vfs_fonts -->
<script type="text/javascript" charset="utf8" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/lib/Buttons-1.1.2/js/vfs_fonts.js">
</script>
<!-- Buttons html5 -->
<script type="text/javascript" charset="utf8" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/lib/Buttons-1.1.2/js/buttons.html5.min.js">
</script>
<!-- Buttons print -->
<script type="text/javascript" charset="utf8" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/lib/Buttons-1.1.2/js/buttons.print.min.js">
</script>
<!-- Buttons colVis -->
<script type="text/javascript" charset="utf8" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/lib/Buttons-1.1.2/js/buttons.colVis.min.js">
</script>
<script type="text/javascript" charset="utf8" src="<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))); ?>/lib/Responsive-2.1.0/js/dataTables.responsive.min.js">
</script>
<div class="wrap">
	<div class="row">
		<div class="col-md-12">
			<h2>lentiManager &nbsp; <a href="javascript:void(0);" onclick="addLentil()" data-toggle="modal" data-target="#addModal" class="btn btn-primary">Add</a></h2> 
		</div>
		<div class="col-md-12">
			<table class="table table-striped table-bordered table-hover"  id="lenti-list">
				<thead>
					<tr>
						<th>Catalog</th>
						<th>Type</th>
						<th>Description</th>
						<th>Volume</th>
						<th>Titer</th>
						<th>Purity</th>
						<th>Size</th>
						<th>Vector</th>
						<th>Delivery Time</th>
						<th>Price</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					
				</tbody>
			</table>
		</div>
	</div>	
</div>
<div class="modal fade" id="addModal" tabindex="-1" role="dialog"  aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" id="add-modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div style="display: inline-block;">
                    <h4 class="modal-title" id="addModalLabel" style="display: inline;margin-right: 20px;">
                    </h4>
                </div>
                <div style="display: inline-block;float: right;margin-right:10px;">
                    <button type="button" class="btn btn-primary addLentil" id="modal_save_button">Save</button>
                    <button type="button" class="btn btn-default close-edit-modal" data-dismiss="modal">Cancel</button>
                </div>
                
            </div>
            <!-- modal-header -->
            <form id="form_add" class="form-inline" >
                <div class="modal-body">
                    <div class="row">
                    	<div class="col-md-12">
	                    	<div class="form-group col-md-6">
		                        <label style="font-size:13px;" for="catalog">
		                            Catalog&nbsp;
		                            <span id="catalog_log" class="valid_log"></span>
		                        </label>
		                        <input type="text" class="form-control" id="catalog" name="catalog" placeholder="" onBlur="checkCatalog()" data-toggle="tooltip" data-placement="top" title="Required. Can only contain letters, numbers, dashes."/>
		                    </div>
		                    <div class="form-group col-md-6">
		                    	<label for="type">
		                    		Type&nbsp;
		                    		<span id="type_log" class="valid_log"></span>
		                    	</label>
		                    	<input type="text" class="form-control" id="type" name="type" title="Required." onBlur="">
		                    </div>
		                    <div class="form-group col-md-6">
		                    	<label for="description">
		                    		Description&nbsp;
		                    		<span id="escription_log" class="valid_log"></span>
		                    	</label>
		                    	<input type="text" class="form-control" id="description" title="Required.">
		                    </div>
	                    </div>
                    </div>
                </div>
                <!-- modal-body -->
                <input id="catalog_ori" name="catalog_ori" type="hidden" />
            </form>
            <!-- /.modal-footer -->
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal -->
</div>
<script type="text/javascript">
	var table;
	jQuery(document).ready(function($) {
        loadLentil();
        $('[data-toggle="tooltip"]').tooltip();
	    
	});
	function loadLentil(){
		table = $('#lenti-list').DataTable({
            // responsive: true,
            "dom": '<"container-fluid"<"row"<"col-md-4"l><"col-md-4"B><"col-md-4"f>>rt<"rol-md-2"><"col-md-2"i>p>',
            "stateSave": true,
            "buttons": [
	            {
	                text:'Reload',
	                action: function( e, dt, node, config ) {
	                   table.ajax.reload();
	                }
	            },
	            {
	                extend:'excel',
	                exportOptions:{columns: ':visible'}
	            },
	            {
	                extend:'pdf',
	                exportOptions:{columns: ':visible'}
	            },
	            {   
	                extend: 'colvis',
	                className: 'colvisButton',
	                columns: ':gt(0)'
	            }
        	],
        	"order": [[ 0, 'asc' ]],
        	"destroy": true,//销毁上一个实例
	        "autoWidth": false,//关闭自动列宽
	        "processing": true,//处理中的提示
	        "serverSide": false,//客户端处理
	        "language": {
	            "sProcessing": "Processing...",
	            "sLengthMenu": "Show _MENU_ entires",
	            "sZeroRecords": "No matching records found.",
	            "sInfo": "Showing _START_ to _END_ of _TOTAL_ entires",
	            "sInfoEmpty": "Showing 0 to 0 of 0 entires",
	            "sInfoFiltered": "(filtered from _MAX_ total entries)",
	            "sSearch": "Search",
	            "sEmptyTable": "No data was found",
	            "sLoadingRecords": "loading...",
	            "sInfoThousands": ",",
	            "oPaginate": {
	                "sPrevious": "Previous",
	                "sNext": "Next"
	            }
	        },
	        "ajax": {//发送ajax请求
	            "url": "<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))) . '/Service/lenti-ajax.php'; ?>",
	            "type": "GET",
	            "data": { action: "listAll"},
	        },
	        "columns": [
		        { 
		            "data": "catalog", 
		            // "render": function ( data, type, full, meta ){
		            //     return '<div style="white-space: nowrap;">'+data+'</div>'; 
		            // },
		            "width": "15%"
		        },
		        {	"data" : "type" },
		        {	"data" : "description",
		        	"render": function ( data, type, full, meta ){
	                    if(data!=null){
	                        return '<div style="overflow: hidden;text-overflow: ellipsis; white-space: nowrap; height: 20px; width:120px; cursor: pointer;" title="'+data+'">'+data+'</div>'; 
	                    }else{
	                        return '';
	                    }
                	},
                	"width": "120"
		    	},
		        {	"data" : "volume", 
		        	"width" : "5%"	},
		        {	"data" : "titer"	},
		        {	"data" : "purity", "width":"5%"	},
		        {	"data" : "size", "width" : "5%"	},
		        {	"data" : "vector"	},
		        {	"data" : "delivery_time", "width" : "10%"	},
		        {	"data" : "price",
		        	"render" : function(data,type,full,meta){
		        		return '$'+data;
		        	},
		        	"width" : "5%"
		        },
		        {
		        	"data": "catalog",
	            //将catalog渲染成两个按钮，点击按钮时将dt单元格的catalog作为参数调用对应的方法
	                "render": function ( data, type, full, meta ){
	                    return '<a class="btn btn-primary btn-xs edit" onclick="editLentil(\''+data+'\',this)">Edit</a>'
	                    +'&nbsp'+
	                    '<a data-toggle="modal" data-target="#deleteModal" class="btn btn-danger btn-xs delete" onclick="deleteLentil(\''+data+'\')">Delete</a>';
	                },"orderable": false
		        }
	        ]
        });
	}
	// 校验是否存在货号
	function checkCatalog(){
	    var catalog = document.getElementById('catalog').value.trim();
	    if (catalog.length==0) {//为空时
	        catalogCheck = false;//使用全局变量存储结果
	        $("#catalog_log").html(' * required！');//提示文字
	        $("#catalog_log").css({color:"#d44950"});//提示着色
	        $("#catalog").css("borderColor","#d44950");//框着色
	    } else {//不为空时
	        var reg_1 = /^[A-Za-z0-9\-]+$/;
	        var r_1 = catalog.match(reg_1);
	        if(r_1==null){//不匹配正则时
	            catalogCheck = false;//使用全局变量存储结果
	            $("#catalog_log").html(' * invalid！');//提示文字
	            $("#catalog_log").css({color:"#d44950"});//提示着色
	            $("#catalog").css("borderColor","#d44950");//框着色
	        } else if(r_1!=null && action=='add') {//添加弹窗中验证通过时查询是否已存在该Catalog（编辑弹窗不验证）
	            $.ajax({
	                /**因为js引擎的单线程机制，这里必需设置为同步（async: false），
	                 * 如果为异步（即 默认 或 async: true）将不会等待ajax结果，而是继续执行ajax之外的代码，
	                 * 直到整个外部方法执行完毕后才执行回调函数，
	                 * 这将导致catalog的校验滞后于form的校验，最终导致保存失败。
	                 */
	                async: false,
	                type: "POST",
	                dataType: "html",
	                url: "<?php echo WP_PLUGIN_URL . '/' . dirname(dirname(plugin_basename(__FILE__))) . '/Service/lenti-ajax.php'; ?>",
	                data: "action=queryRep&catalog="+catalog,
	                success: function(d){//不存在重复
	                    if(d==0){
	                        catalogCheck = true;
	                        $("#catalog_log").html('');//提示文字
	                        $("#catalog").css("borderColor","");//框着色
	                    } else {//存在重复时
	                        catalogCheck = false;
	                        $("#catalog_log").html(' * already exists！');//提示文字
	                        $("#catalog_log").css({color:"#d44950"});//提示着色
	                        $("#catalog").css("borderColor","#d44950");//框着色
	                    }
	                }
	            });
	        } else if(r_1!=null && action=='edit') {//（编辑弹窗不验证）
	            catalogCheck = true;
	        }
	    }
	    return catalogCheck;
	}
	function editLentil(catalog,obj){
		$("#addModal").modal().find("#addModalLabel").text('Edit Lentivirus');
	}
	function deleteLentil(catalog){
		alert("delete");
	}
	//点击页面内的添加按钮时
	function addLentil(){
		action = 'add';
	   	$("#addModalLabel").text("Add Lentivirus");
	   
	}
</script>